<template>
  <div>
    <NavBar :title="t('teamManagerText')" />
    <div class="team-set-container" v-if="team">
      <div class="team-set-card">
        <div class="team-set-item">
          <div class="team-members-info-item" @tap="goTeamManagerList">
            <div class="team-members-info">
              <div class="team-info-title">
                {{ t('teamManagerSettingText') }}
              </div>
              <div class="team-info-subtitle">
                {{ teamManagerNum }}
              </div>
            </div>
            <Icon iconClassName="more-icon" color="#999" type="icon-jiantou" />
          </div>
        </div>
      </div>
      <div class="team-set-card">
        <picker
          @change="onUpdateTeamMode"
          :value="updateTeamMode.value"
          :range="rangeArr"
        >
          <div class="team-set-item team-set-item-flex">
            <div>
              <div>{{ t('updateTeamInfoText') }}</div>
              <div class="team-item-value-text">{{ updateTeamMode.text }}</div>
            </div>
            <Icon iconClassName="more-icon" color="#999" type="icon-jiantou" />
          </div>
        </picker>
        <picker
          @change="onUpdateInviteMode"
          :value="inviteMode.value"
          :range="rangeArr"
        >
          <div class="team-set-item team-set-item-flex">
            <div>
              <div>{{ t('updateTeamInviteText') }}</div>
              <div class="team-item-value-text">{{ inviteMode.text }}</div>
            </div>
            <Icon iconClassName="more-icon" color="#999" type="icon-jiantou" />
          </div>
        </picker>
        <picker
          @change="onUpdateExt"
          :value="teamAtMode.value"
          :range="rangeArr"
        >
          <div class="team-set-item team-set-item-flex">
            <div>
              <div>{{ t('updateTeamAtText') }}</div>
              <div class="team-item-value-text">{{ teamAtMode.text }}</div>
            </div>
            <Icon iconClassName="more-icon" color="#999" type="icon-jiantou" />
          </div>
        </picker>
      </div>
      <div class="group-set-button" v-if="isGroupOwner" @tap="goTransformTeam">
        {{ t('transformTeam') }}
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import NavBar from '../../../components/NavBar.vue'
import Icon from '../../../components/Icon.vue'
//@ts-ignore
import { onLoad } from '@dcloudio/uni-app'
import { ref, computed, onUnmounted } from 'vue'
import { autorun } from '../../../utils/module/im-store-v2/uniapp/index.esm.js'
import { t } from '../../../utils/i18n'
import { customNavigateTo } from '../../../utils/customNavigate'
import { ALLOW_AT } from '../../../utils/constants'

import type {
  V2NIMTeam,
  V2NIMTeamMember,
} from '../../../utils/module/nim-web-sdk/esm/nim/src/V2NIMTeamService'
import type { YxServerExt } from '../../../utils/store'
import { V2NIMConst } from '../../../utils/nim'

const rangeArr = [t('teamAll'), t('teamOwnerAndManagerText')]

let teamId = ''
const team = ref<V2NIMTeam>()
const teamMembers = ref<V2NIMTeamMember[]>([])

/** 是否是群主 */
const isGroupOwner = computed(() => {
  const myUser = uni.$UIKitStore.userStore.myUserInfo
  return (
    (team.value ? team.value.ownerAccountId : '') ===
    (myUser ? myUser.accountId : '')
  )
})

// const isGroupManager = computed(() => {
//   const myUser = uni.$UIKitStore.userStore.myUserInfo
//   return teamMembers.value
//     .filter(
//       (item) =>
//         item.memberRole ===
//         V2NIMConst.V2NIMTeamMemberRole.V2NIM_TEAM_MEMBER_ROLE_MANAGER
//     )
//     .some((member) => member.accountId === (myUser ? myUser.accountId : ''))
// })

const teamManagerNum = computed(() => {
  return teamMembers.value.filter(
    (item) =>
      item.memberRole ===
      V2NIMConst.V2NIMTeamMemberRole.V2NIM_TEAM_MEMBER_ROLE_MANAGER
  ).length
})

const updateTeamMode = computed(() => {
  return {
    value:
      team.value?.updateInfoMode ===
      V2NIMConst.V2NIMTeamUpdateInfoMode.V2NIM_TEAM_UPDATE_INFO_MODE_MANAGER
        ? 1
        : 0,
    text:
      team.value?.updateInfoMode ===
      V2NIMConst.V2NIMTeamUpdateInfoMode.V2NIM_TEAM_UPDATE_INFO_MODE_MANAGER
        ? t('teamOwnerAndManagerText')
        : t('teamAll'),
  }
})

const inviteMode = computed(() => {
  return {
    value:
      team.value?.inviteMode ===
      V2NIMConst.V2NIMTeamInviteMode.V2NIM_TEAM_INVITE_MODE_MANAGER
        ? 1
        : 0,
    text:
      team.value?.inviteMode ===
      V2NIMConst.V2NIMTeamInviteMode.V2NIM_TEAM_INVITE_MODE_MANAGER
        ? t('teamOwnerAndManagerText')
        : t('teamAll'),
  }
})

const teamAtMode = computed(() => {
  let ext: YxServerExt = {}
  try {
    ext = JSON.parse(team.value?.serverExtension || '{}')
  } catch (error) {
    //
  }
  return {
    value: ext[ALLOW_AT] === 'manager' ? 1 : 0,
    text:
      ext[ALLOW_AT] === 'manager' ? t('teamOwnerAndManagerText') : t('teamAll'),
  }
})

const onUpdateTeamMode = (e: any) => {
  onUpdateTeamInfo('updateInfoMode', e.detail.value == 0 ? 'all' : 'manager')
}

const onUpdateInviteMode = (e: any) => {
  onUpdateTeamInfo('inviteMode', e.detail.value == 0 ? 'all' : 'manager')
}

const onUpdateExt = (e: any) => {
  onUpdateTeamInfo('serverExtension', e.detail.value == 0 ? 'all' : 'manager')
}

const onUpdateTeamInfo = async (
  key: keyof V2NIMTeam,
  value: 'manager' | 'all'
) => {
  const params: Partial<V2NIMTeam> = {
    teamId,
  }
  switch (key) {
    case 'updateInfoMode':
      params.updateInfoMode =
        value === 'all'
          ? V2NIMConst.V2NIMTeamUpdateInfoMode.V2NIM_TEAM_UPDATE_INFO_MODE_ALL
          : V2NIMConst.V2NIMTeamUpdateInfoMode
              .V2NIM_TEAM_UPDATE_INFO_MODE_MANAGER
      break
    case 'inviteMode':
      params.inviteMode =
        value === 'all'
          ? V2NIMConst.V2NIMTeamInviteMode.V2NIM_TEAM_INVITE_MODE_ALL
          : V2NIMConst.V2NIMTeamInviteMode.V2NIM_TEAM_INVITE_MODE_MANAGER
      break
    case 'serverExtension': {
      let ext: YxServerExt = {}
      try {
        ext = JSON.parse(team.value?.serverExtension || '{}')
      } catch (error) {
        //
      }
      ext[ALLOW_AT] = value
      params.serverExtension = JSON.stringify(ext)
      break
    }
  }

  try {
    //@ts-ignore
    await uni.$UIKitStore.teamStore.updateTeamActive({ teamId, info: params })
  } catch (error: any) {
    switch (error?.code) {
      // 无权限
      case 109432:
        uni.showToast({
          title: t('noPermission'),
          icon: 'error',
        })
        break
      default:
        uni.showToast({
          title: t('updateTeamFailedText'),
          icon: 'error',
        })
        break
    }
  }
}

const goTransformTeam = () => {
  customNavigateTo({
    url: `/pages/Team/team-set/transform-team?id=${teamId}`,
  })
}

/** 群管理员界面 */
const goTeamManagerList = () => {
  customNavigateTo({
    url: `/pages/Team/team-set/team-manager-list?id=${teamId}`,
  })
}
let uninstallTeamWatch = () => {}
onLoad((option) => {
  teamId = option ? option.id : ''
  autorun(() => {
    if (teamId) {
      team.value = uni.$UIKitStore.teamStore.teams.get(teamId)
      teamMembers.value = uni.$UIKitStore.teamMemberStore.getTeamMember(teamId)
    }
  })
})

onUnmounted(() => {
  uninstallTeamWatch()
})
</script>

<style lang="scss" scoped>
@import '../../styles/common.scss';

page {
  padding-top: var(--status-bar-height);
  height: 100vh;
  overflow: hidden;
}

.team-set-container {
  height: 100vh;
  box-sizing: border-box;
  background-color: #eff1f4;
  padding: 10px 20px;
}

.team-set-card {
  background: #ffffff;
  border-radius: 8px;
  padding-left: 16px;
  margin-bottom: 10px;
}

.group-set-button {
  text-align: center;
  background: #ffffff;
  border-radius: 8px;
  color: #e6605c;
  height: 40px;
  line-height: 40px;
}

.team-item-value-text {
  color: #999;
  font-size: 14px;
}

.team-set-item {
  border-bottom: 1rpx solid #f5f8fc;
}

.team-set-item-flex {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
}

.more-icon {
  margin: 0 16px;
  color: #999999;
}

.group-info-item {
  height: 70px;
  display: flex;
  align-items: center;

  .team-info-title {
    font-size: 16px;
    margin-left: 10px;
    width: 0;
    flex: 1;
    overflow: hidden; //超出的文本隐藏
    text-overflow: ellipsis; //溢出用省略号显示
    white-space: nowrap; //溢出不换行
  }
}

.group-members-item {
  height: 90px;
}

.team-members-info-item {
  display: flex;
  align-items: center;
}

.team-members-info {
  height: 40px;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex: 1;

  .team-info-subtitle {
    color: #999999;
  }
}

.member-list {
  white-space: nowrap;
  overflow-x: hidden;
  margin-right: 30px;
  height: 50px;
  display: flex;
  align-items: center;
}

.member-add {
  width: 32px;
  height: 32px;
  border-radius: 100%;
  border: 1px dashed #999999;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 10px;
  flex-shrink: 0;
}

.member-item {
  margin-right: 10px;
  display: inline-block;
  flex-shrink: 0;
}
</style>
