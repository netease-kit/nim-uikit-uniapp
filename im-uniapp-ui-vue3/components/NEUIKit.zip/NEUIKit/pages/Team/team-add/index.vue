<template>
  <div>
    <NavBar :title="t('friendSelectText')" />
    <PersonSelect
      :personList="friendList"
      @checkboxChange="checkboxChange"
      :showBtn="true"
      :onBtnClick="addTeamMember"
    >
    </PersonSelect>
  </div>
</template>

<script lang="ts" setup>
import PersonSelect, {
  PersonSelectItem,
} from "../../../components/PersonSelect.vue";
import { ref } from "vue";
import NavBar from "../../../components/NavBar.vue";
import { t } from "../../../utils/i18n";
//@ts-ignore
import { onLoad, onUnload } from "@dcloudio/uni-app";
import { debounce } from "../../../utils";
import { events } from "../../../utils/constants";

// 好友列表
const friendList = ref<PersonSelectItem[]>([]);
// 群ID
let teamId = "";

let newTeamMember: string[] = [];

const checkboxChange = (selectList: string[]) => {
  newTeamMember = selectList;
};
// 添加群成员
const addTeamMember = debounce(() => {
  // 群成员数量存在限制
  if (newTeamMember.length > 200) {
    uni.showToast({
      title: t("maxSelectedText"),
      icon: "none",
    });
    return;
  }
  if (newTeamMember.length == 0) {
    uni.showToast({
      title: t("friendSelect"),
      icon: "none",
    });
    return;
  }

  uni.$UIKitStore?.teamMemberStore
    .addTeamMemberActive({ teamId, accounts: newTeamMember })
    .then(async () => {
      uni.navigateBack({
        delta: 1,
      });
    })
    .catch((err: any) => {
      switch (err ? err.code : "") {
        case 109306:
          uni.showToast({
            title: t("noPermission"),
            icon: "error",
          });
          break;
        default:
          uni.showToast({
            title: t("addTeamMemberFailText"),
            icon: "none",
          });
          break;
      }
    });
}, 800);

onLoad((props: any) => {
  const _friendList = uni.$UIKitStore.uiStore.friends.filter(
    (item: any) =>
      !uni.$UIKitStore.relationStore.blacklist.includes(item.accountId),
  );

  teamId = props ? props.teamId : "";

  const res = uni.$UIKitStore.teamMemberStore.getTeamMember(teamId);
  const _teamMembers = res.map((item: any) => {
    return item.accountId;
  });
  friendList.value = _friendList.map((item: any) => {
    if (_teamMembers.includes(item.accountId)) {
      return { accountId: item.accountId, disabled: true };
    } else {
      return { accountId: item.accountId };
    }
  });

  uni.$on(events.FRIEND_SELECT, () => {
    addTeamMember();
  });
});

onUnload(() => {
  uni.$off(events.FRIEND_SELECT);
});
</script>

<style lang="scss" scoped>
@import "../../styles/common.scss";

.group-input-wrapper {
  display: flex;
  align-items: center;

  .group-input {
    margin: 10px;
    background-color: #f2f4f5;
    padding: 4px;
    border-radius: 5px;
    flex: 1;
  }

  .button {
    width: 65px;
    height: 30px;
    font-size: 12px;
    text-align: center;
    line-height: 30px;
    margin-right: 5px;
    padding: 0;
    color: #5c9bed;
  }
}

.placeholder {
  color: #a6adb6;
}

.right-button {
  color: #5c9bed;
}
</style>
